package com.example.websocket.model;

public enum UserType {
    Server,
    Me,
    Service
};