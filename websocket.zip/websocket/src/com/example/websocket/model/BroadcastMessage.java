package com.example.websocket.model;

import com.pinta.ws_service.Consts.WsConstant;

public class BroadcastMessage {
	 public String id;
	 public String message;
}