package com.example.websocket.model;

import android.view.View;
import android.widget.TextView;
