/** Automatically generated file. DO NOT MODIFY */
package com.example.websocket;

public final class BuildConfig {
    public final static boolean DEBUG = true;
    public final static String WEBSOCKET_URL = "ws://192.168.1.87:5414";
    //public final static String WEBSOCKET_URL = "ws://192.168.0.24:5414";
    //public final static String WEBSOCKET_URL = "ws://192.168.1.3:81";
}